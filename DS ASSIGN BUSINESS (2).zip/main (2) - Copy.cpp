#include <iostream>
#include "header.hpp"


int main() {
    // Initialize the root of the BST to null
    Employee* root = NULL;
    // Initialize the queue for attendance to be empty
    queue<string> attendance;
    // Initialize the array of collaboration files
    CollaborationFile files[10];
    // Initialize the map of projects assigned to employees
    map<int, Project> projects;

    // Print the menu
    cout << "Software Company Management System" << endl;
    cout << "1. Add an employee" << endl;
    cout << "2. Search an employee" << endl;
    cout << "3. Mark an employee as present" << endl;
    cout << "4. Mark an employee as absent" << endl;
    cout << "5. Print the current attendance list" << endl;
    cout << "6. Calculate the total cost of all employees' salaries" << endl;
    cout << "7. Create a collaboration file" << endl;
    cout << "8. Access a collaboration file" << endl;
    cout << "9. Release a collaboration file" << endl;
    cout << "10. Assign a project to an employee" << endl;
    cout << "11. Print the projects assigned to each employee" << endl;
    cout << "12. Print the list of employees (depth-first search traversal)" << endl;
    cout << "13. Quit" << endl;

    // Loop until the user chooses to quit
    int choice;
    do {
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
                case 1: {
    // Add a new employee
    int id;
    string name, phone, manager;
    cout << "Enter the employee's ID: ";
    cin >> id;
    cout << "Enter the employee's name: ";
    cin.ignore();
    getline(cin, name);
    cout << "Enter the employee's phone number: ";
    getline(cin, phone);
    cout << "Enter the employee's manager name: ";
    getline(cin, manager);
    root = insertEmployee( root,  id,  name,  phone,  manager);
    cout << "Employee added successfully." << endl;
    break;
}
case 2: {
    // Search for an employee
    string name;
    cout << "Enter the employee's Name: ";
    cin >> name;
    Employee* employee = searchEmployee(root, name);
    if (employee == NULL) {
        cout << "Employee with name " << name << " not found." << endl;
    } else {
        cout << "Employee with name " << name << " found: "  << endl;
    }
    break;
}

case 3: {
// Mark an employee as present
string name;
cout << "Enter the employee's name: ";
cin.ignore();
getline(cin, name);
markPresent(attendance,  name);
  
break;
}
case 4: {
// Mark an employee as absent
string name, employeeName;
cout << "Enter the employee's name: ";
cin.ignore();
getline(cin, name);

markAbsent(attendance);
break;
}
case 5: {
// Print the current attendance list
  
printAttendance(attendance);
break;
}
case 6: {
// Calculate the total cost of all employees' salaries
  double salaryPerHour;
double totalCost = calculateSalaryCost(root, salaryPerHour);
cout << "The total cost of all employees' salaries is $" << totalCost << endl;
break;
}
case 7: {
// Create a collaboration file
string name, description;
int fileId;
cout << "Enter the name of the file: ";
cin.ignore();
getline(cin, name);
cout << "Enter the description of the file: ";
getline(cin, description);
//fileId = (Convert.ToInt32)(createCollaborationFile( name, description));
cout << "File created successfully with ID " << fileId << "." << endl;
break;
}
case 8: {
// Access a collaboration file
int fileId, employeeId;
cout << "Enter the ID of the file: ";
cin >> fileId;
cout << "Enter the ID of the employee: ";
cin >> employeeId;
accessCollaborationFile(files, fileId, employeeId);
break;
}
case 9: {
// Release a collaboration file
int fileId, employeeId;
cout << "Enter the ID of the file: ";
cin >> fileId;
cout << "Enter the ID of the employee: ";
cin >> employeeId;
releaseCollaborationFile(files, fileId, employeeId);
break;
}
case 10: {
// Assign a project to an employee
int employeeId;
string projectName, projectDescription;
cout << "Enter the ID of the employee: ";
cin >> employeeId;
cout << "Enter the name of the project: ";
cin.ignore();
getline(cin, projectName);
cout << "Enter the description of the project: ";
getline(cin, projectDescription);
assignProject(projects, employeeId, projectName, projectDescription);
break;
}
case 11: {
// Print the projects assigned to each employee
printProjects(projects);
break;
}
case 12: {
// Print the list of employees (depth-first search traversal)
cout << "List of employees:" << endl;
printEmployees(root);
break;
}
case 13: {
// Quit the program
cout << "Exiting program." << endl;
break;
}
default: {
// Invalid choice
cout << "Invalid choice. Please try again." << endl;
break;
}
}
} while (choice != 13);
return 0;
}

