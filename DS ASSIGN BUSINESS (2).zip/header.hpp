#ifndef HEADER_HPP_INCLUDED
#define HEADER_HPP_INCLUDED
#include<bits/stdc++.h>
#include <math.h>
#include <iostream>
#include <string>
#include <queue>
#include <map>
#include <fstream>
#include <sstream>
using namespace std;

// Define a struct to represent an employee
struct Employee {
    int id;
    string name;
    string phone;
    string manager;
    Employee* left;
    Employee* right;
};

// Define a struct to represent a project
struct Project {
    string name;
    string description;
};

// Define a struct to represent a collaboration file
struct CollaborationFile {
    string name;
    string description;
    bool isBeingAccessed;
};
// Insert an employee into the BST using Recursion
Employee* insertEmployee(Employee* root, int id, string name, string phone, string manager) {
    // If the root is null, create a new employee and set it as the root
    if (root == NULL) {
        Employee* newEmployee = new Employee;
        newEmployee->id = id;
        newEmployee->name = name;
        newEmployee->phone = phone;
        newEmployee->manager = manager;
        newEmployee->left = NULL;
        newEmployee->right = NULL;
        return newEmployee;
    }
    // Otherwise, compare the new employee's name to the current node's name
    int cmp = name.compare(root->name);
    // If the new employee's name is less than the current node's name, insert it into the left subtree
    if (cmp < 0) {
        root->left = insertEmployee(root->left, id, name, phone, manager);
    }
    // If the new employee's name is greater than the current node's name, insert it into the right subtree
    else if (cmp > 0) {
        root->right = insertEmployee(root->right, id, name, phone, manager);
    }
    // If the new employee's name is the same as the current node's name, do nothing
    return root;
}
// Function to perform a DFS traversal of the BST
void dfs(Employee* root) {
    if (root != NULL) {
        cout << root->id << " - " << root->name << endl;
        dfs(root->left);
        dfs(root->right);
    }
}
// Search for an employee in the BST using Recursion
Employee* searchEmployee(Employee* root, string name) {
    // If the root is null or the employee's name matches the current node's name, return the current node
    if (root == NULL || root->name == name) {
        return root;
    }
    // If the employee's name is less than the current node's name, search the left subtree
    if (name.compare(root->name) < 0) {
        return searchEmployee(root->left, name);
    }
    // If the employee's name is greater than the current node's name, search the right subtree
    return searchEmployee(root->right, name);
}

// Function to mark an employee as present
void markPresent(queue<string>& attendance, string employeeName) {
    attendance.push(employeeName);
  cout << "Marked " << employeeName << " as present." << endl;
}

// Function to mark an employee as absent
void markAbsent(queue<string>& attendance) {
    if (!attendance.empty()) {
string employeeName = attendance.front();
        attendance.pop();
      cout << "Marked " << employeeName << " as absent." << endl;
    } else {
        cout << "Attendance queue is empty." << endl;
    }    
}

// Function to print the current attendance list
void printAttendance(queue<string> attendance) {
    cout << "Current attendance list:" << endl;
    while (!attendance.empty()) {
        cout << attendance.front() << endl;
        attendance.pop();
    }
}

// Function to calculate the total cost of all employees' salaries
double calculateSalaryCost(Employee* root, double salaryPerHour) {
    if (root == NULL) {
        return 0;
    }
    double hoursWorked = 8; // Assume all employees work 8 hours per day
    double salary = salaryPerHour * hoursWorked * 20; 
   // Assume all employees work 20 days per month
    return salary + calculateSalaryCost(root->left, salaryPerHour) + calculateSalaryCost(root->right, salaryPerHour);
}

// Function to create a collaboration file
CollaborationFile createCollaborationFile(std::string name, std::string description) {
    CollaborationFile file;
    file.name = name;
    file.description = description;
    file.isBeingAccessed = false;
    return file;
}

// Function to access a collaboration file
void accessCollaborationFile(CollaborationFile* files, int fileId, int employeeId) {
    files[fileId].isBeingAccessed = true;
    cout << "Employee with ID " << employeeId << " is accessing file " << files[fileId].name << endl;
}

// Function to release a collaboration file
void releaseCollaborationFile(CollaborationFile* files, int fileId, int employeeId) {
    files[fileId].isBeingAccessed = false;
    cout << "Employee with ID " << employeeId << " has released file " << files[fileId].name << endl;
}

// Function to assign a project to an employee
void assignProject(map<int, Project>& projects, int employeeId, string projectName, string projectDescription) {
    Project project;
    project.name = projectName;
    project.description = projectDescription;
    projects[employeeId] = project;
}




// Function to print the projects assigned to each employee
void printProjects(map<int, Project> projects) {
    cout << "Projects assigned to employees:" << endl;
    for (auto& it : projects) {
        cout << "Employee with ID " << it.first << ": " << it.second.name << " - " << it.second.description << endl;
    }
  
}
// Function to print the employees
void printEmployees(Employee* root) {
    if (root == NULL) {
        return;
    }
    printEmployees(root->left);
    cout << root->name << " (" << root->phone << ", Manager: " << root->manager << ")" << endl;
    printEmployees(root->right);
}
#endif//
HEADER_HPP_INCLUDED

